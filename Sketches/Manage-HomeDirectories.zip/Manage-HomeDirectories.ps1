#region Parameter definition
####################################################################################

[CmdletBinding()]
param
(
    [Parameter()]
    [Array]
    $PeopleToSync,

    [Parameter()]
    [Array]
    $PeopleToRemove
)

#endregion

#region Constants
####################################################################################

$ErrorActionPreference = "Stop"
$HomeDriveBasePathTeacher = "\\fileprint\g$\Shares\Home_L"
$HomeDriveBasePathStudent = "\\fileprint\g$\Shares\Home_S"
$HomeDriveArchive = "\\fileprint\g$\Shares\Archiv"

#endregion

#region Configuration
####################################################################################

# Prevent Debug switch from causing the PowerShell host to pause
if ($PSBoundParameters["Debug"]) {
    $DebugPreference = "Continue"
}

if ($PeopleToSync -ne $null) {

    Write-Debug "People to sync:"

    foreach ($PersonToSync in $PeopleToSync.GetEnumerator()) {
        Write-Debug "FullName=""$($PersonToSync.FullName)""  UserPrincipalName=""$($PersonToSync.UserPrincipalName)""."
    }
}

if ($PeopleToRemove -ne $null) {

    Write-Debug "People to remove:"

    foreach ($PersonToRemove in $PeopleToRemove.GetEnumerator()) {
        Write-Debug "FullName=""$($PersonToRemove.FullName)""  UserPrincipalName=""$($PersonToRemove.UserPrincipalName)""."
    }
}

#endregion

#region Functions
####################################################################################


function Add-Output
{
    Param
    (
        [int] $personId,
        [string] $errorMessage
    )

    $o= [PSCustomObject] @{ 
        Id = $personId
        ErrorMessage = $errorMessage
    }

    Write-Output $o
}

function Get-HomePath
{
    Param
    (
        [PSObject] $Person
    )
    
    If (@(1,3,5,7) -contains $Person.PersonTypeId){
        $basePath = $HomeDriveBasePathStudent
    }else{
        $basePath = $HomeDriveBasePathTeacher
    }

    Return "$($basePath)\$($Person.SamAccountName)"

}

function Remove-People
{
    Param
    (
    )

    foreach ($person in $PeopleToRemove) {
        $errorMessage = $null
        
        Try
        {
            $path = Get-HomePath $person

            If (Test-Path $path) {
                $destination = $HomeDriveArchive | Join-Path -ChildPath $person.SamAccountName

                While (Test-Path $destination) {
                    $destination += "1"                
                }

                Move-Item -Path $path -Destination $destination
            }
        } Catch {
            $errorMessage = $_.Exception.Message
            Write-Verbose $errorMessage
        }
        Add-Output -personId $person.Id -errorMessage $errorMessage
    }
}

function Sync-People {
    Param
    (
    )

    foreach ($person in $PeopleToSync)
    {
        $errorMessage = $null

        Try
        {
            $path = Get-HomePath $person

            If (-not (Test-Path $path)) {
                Write-Information "Create new home directory. $($path)"
                $errorMessage = Create-Home -Path $path

                If ($errorMessage -eq $null){
                    $errorMessage = Set-Permission -Person $person -Path $path
                }
            }
        } Catch {
            $errorMessage = $_.Exception.Message
            Write-Verbose $errorMessage
        }
        
        Add-Output -personId $person.Id -errorMessage $errorMessage
    }
}

function Set-Permission {
    Param
    (
        [PSObject] $Person,
        [string] $Path
    )
         
    $errorMessage = $null

    Try
    { 
        $Acl = (Get-Item $Path).GetAccessControl('Access')
        $Ar = New-Object System.Security.AccessControl.FileSystemAccessRule($Person.UserPrincipalName, 'Modify','ContainerInherit,ObjectInherit', 'None', 'Allow')
        $Acl.SetAccessRule($Ar)
        Set-Acl -path $Path -AclObject $Acl
    } Catch {
        $errorMessage = "Error setting permissions for Home Directory"
        Write-Error $_.Exception.Message
    }

    return $errorMessage
}

function Create-Home {
    Param
    (
        [string] $Path
    )

    $errorMessage = $null

    Try
    { 
        New-Item -ItemType Directory -Path $Path -Force | Out-Null

        If (-not(Test-Path $Path)) {
            $errorMessage = "Home Directory was not created."
        }
    } Catch {
        $errorMessage = "Error while creating new Home Directory."
        Write-Error $_.Exception.Message
    }

    return $errorMessage
}

#endregion

#region Main code
####################################################################################

Remove-People
Sync-People

#endregion