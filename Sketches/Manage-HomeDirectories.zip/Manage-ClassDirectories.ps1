#region Parameter definition
####################################################################################

[CmdletBinding()]
param
(
    [Parameter()]
    [Array]
    $GroupsToSync,

    [Parameter()]
    [Array]
    $GroupsToRemove
)

#endregion

#region Constants
####################################################################################

$ClassDriveBasePath = "\\fileprint\f$\Shares\Klassen"
$ClassDriveArchive = "\\fileprint\f$\Shares\KlassenArchiv"
$adminGroupGuid = "37467479-7eca-4038-9724-71a79be858ef"
$sysadminGroup = "G_Sysadmin"

#endregion

#region Configuration
####################################################################################

# Prevent Debug switch from causing the PowerShell host to pause
if ($PSBoundParameters["Debug"]) {
    $DebugPreference = "Continue"
}

if ($GroupsToSync -ne $null) {

    Write-Debug "Groups to sync:"

    foreach ($GroupToSync in $GroupsToSync.GetEnumerator()) {
        Write-Debug "FullName=""$($GroupToSync.FullName)""  UserPrincipalName=""$($GroupToSync.UserPrincipalName)""."
    }
}

if ($GroupsToRemove -ne $null) {

    Write-Debug "Groups to remove:"

    foreach ($GroupToRemove in $GroupsToRemove.GetEnumerator()) {
        Write-Debug "FullName=""$($GroupToRemove.FullName)""  UserPrincipalName=""$($GroupToRemove.UserPrincipalName)""."
    }
}

#endregion

#region Functions
####################################################################################

function Remove-Groups
{
    Param
    (
    )

    foreach ($group in $GroupsToRemove)
    {
        $errorMessage = $null

        if (@(5,6,7,8) -contains $group.GroupTypeId) {
            Try
            {
                $path = Get-ClassDrivePath $group

                If (Test-Path $path) {
                    $destination = $ClassDriveArchive | Join-Path -ChildPath (Split-Path -Path $path -Leaf )

                    While (Test-Path $destination) {
                        $destination += "1"                
                    }

                    Move-Item -Path $path -Destination $destination
                }
            } Catch {
                $errorMessage = $_.Exception.Message
                Write-Verbose $errorMessage
            }
        }
    
        Add-Output -groupId $group.Id -errorMessage $errorMessage
    }
}

function Sync-Groups
{
    Param
    (
    )

    foreach ($group in $GroupsToSync)
    {
        $errorMessage = $null

        Try
        {
            $path = Get-ClassDrivePath $group

            If (-not (Test-Path $path)) {
                Write-Information "Create new class directory. $($path)"
                $errorMessage = Create-ClassDrive -Path $path
            }
			
			Start-Sleep -s 20

            If ($errorMessage -eq $null){
                $errorMessage = Set-Permission -Group $group -Path $path
            }
        } Catch {
            $errorMessage = $_.Exception.Message
            Write-Error $errorMessage
        }
    
        Add-Output -groupId $group.Id -errorMessage $errorMessage
    }
}

function Set-Permission {
    Param
    (
        [PSCustomObject] $Group,
        [string] $Path
    )
     
    $errorMessage = $null

    Try
    { 
        Write-Information "Set Permissions for '$($Path)'"

        $adminGroup = Get-ADGroup -Identity $adminGroupGuid
        $grp = Get-ADGroup -Identity $Group.ActiveDirectoryGuid

        $acl = Get-Acl -Path $Path
        $acl.SetAccessRuleProtection($true, $false)
        $accessRuleAdmin = New-Object System.Security.AccessControl.FileSystemAccessRule($adminGroup.SamAccountName, 'FullControl','ContainerInherit,ObjectInherit', 'None', 'Allow')
        $accessRuleSysAdmin = New-Object System.Security.AccessControl.FileSystemAccessRule($sysadminGroup, 'Modify','ContainerInherit,ObjectInherit', 'None', 'Allow')
        $accessRuleGroup = New-Object System.Security.AccessControl.FileSystemAccessRule($grp.SamAccountName, 'Modify','ContainerInherit,ObjectInherit', 'None', 'Allow')
        $acl.SetAccessRule($accessRuleAdmin)
        $acl.SetAccessRule($accessRuleSysAdmin)
        $acl.SetAccessRule($accessRuleGroup)
        
        Set-Acl -path $Path -AclObject $acl
    } Catch {
        $errorMessage = "Error setting permissions for Class Directory"
        Write-Error $_.Exception.Message
    }

    return $errorMessage
}

#endregion

#region Main code
####################################################################################

Remove-Groups
Sync-Groups

#endregion